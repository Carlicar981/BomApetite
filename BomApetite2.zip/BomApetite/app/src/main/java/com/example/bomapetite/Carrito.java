package com.example.bomapetite;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.bomapetite.adapter.AdaptadorCarrito;
import com.example.bomapetite.adapterPlatos.AdaptadorPlatos;

import java.util.ArrayList;

public class Carrito extends AppCompatActivity {
    TextView titulo,botonCheck,textCarrito;
    RecyclerView recycler;
    ArrayList<Platos> listaCarrito;
    int totalCarrito = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrito);
        textCarrito = findViewById(R.id.textCarrito);
        ArrayList<Platos> lista=(ArrayList<Platos>) getIntent().getSerializableExtra("carrito");
        if (lista==null || lista.size()<0){
            textCarrito.setText("NO HAY PRODUCTOS EN EL CARRITO");
        }else {
            textCarrito.setVisibility(View.INVISIBLE);
            titulo = findViewById(R.id.carrito);
            botonCheck = findViewById(R.id.buttonCheckout3);
            recycler = (RecyclerView) findViewById(R.id.recyclerCarrito);
            recycler.setLayoutManager(new LinearLayoutManager(this));
            AdaptadorCarrito adaptadorPlatos = new AdaptadorCarrito(lista);
            recycler.setAdapter(adaptadorPlatos);
            float precio =0;
            for (int i=0;i<lista.size();i++){
                precio+=lista.get(i).precio();
            }
            botonCheck.setText("PAGAR "+precio+" €");
        }

    }
}