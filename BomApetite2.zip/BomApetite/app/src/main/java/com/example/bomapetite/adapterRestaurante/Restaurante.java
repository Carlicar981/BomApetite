package com.example.bomapetite.adapterRestaurante;

import java.io.Serializable;

public class Restaurante implements Serializable {
    private String nombre;
    private String info;
    private String descipcion;
    private int foto;

    public Restaurante() {
    }

    public Restaurante(String nombre, String info,String descipcion, int foto) {
        this.nombre = nombre;
        this.info = info;
        this.descipcion=descipcion;
        this.foto = foto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getInfo() {
        return info;
    }
    public String getDescipcion() {
        return descipcion;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }
}
